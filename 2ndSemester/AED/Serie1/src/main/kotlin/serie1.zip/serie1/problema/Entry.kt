package serie1.problema

data class Entry(val value: Int = 0, val file: Int = 0) : Comparable<Entry> {
    override fun compareTo(other: Entry): Int {
        return this.value.compareTo(other.value)
    }
}